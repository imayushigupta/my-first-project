/**
 * Camera Controller Module
 * Handles browser media devices stream, starting/stopping webcam, listing camera options,
 * and capturing video frames onto a canvas.
 */

export class CameraController {
    constructor() {
        /** @type {MediaStream|null} */
        this.stream = null;
        /** @type {HTMLVideoElement|null} */
        this.videoElement = null;
    }

    /**
     * Fetch list of available video input devices (cameras).
     * @returns {Promise<Array<{id: string, label: string}>>}
     */
    async getCameras() {
        try {
            // First request basic permissions if not already granted so labels are populated
            await navigator.mediaDevices.getUserMedia({ video: true }).then(stream => {
                // Instantly shut down the temporary stream
                stream.getTracks().forEach(track => track.stop());
            }).catch(() => {});

            const devices = await navigator.mediaDevices.enumerateDevices();
            return devices
                .filter(device => device.kind === 'videoinput')
                .map((device, index) => ({
                    id: device.deviceId,
                    label: device.label || `Camera ${index + 1}`
                }));
        } catch (e) {
            console.error("Failed to enumerate video devices", e);
            return [];
        }
    }

    /**
     * Start web camera stream on a video element.
     * @param {HTMLVideoElement} videoElement - The target video element.
     * @param {string|null} deviceId - Target camera ID, or null for default.
     * @returns {Promise<boolean>} - True if started successfully.
     */
    async startCamera(videoElement, deviceId = null) {
        this.stopCamera(); // Stop any running stream first
        this.videoElement = videoElement;

        const constraints = {
            video: {
                width: { ideal: 1920 }, // Try to get high resolution for better OCR
                height: { ideal: 1080 },
                facingMode: deviceId ? undefined : { ideal: 'environment' } // Prefer back camera on mobile
            },
            audio: false
        };

        if (deviceId) {
            constraints.video.deviceId = { exact: deviceId };
        }

        try {
            this.stream = await navigator.mediaDevices.getUserMedia(constraints);
            this.videoElement.srcObject = this.stream;
            this.videoElement.setAttribute('playsinline', 'true'); // Prevents iOS from opening full screen video
            await this.videoElement.play();
            return true;
        } catch (e) {
            console.error("Error starting camera stream", e);
            return false;
        }
    }

    /**
     * Stop the camera stream and clean up track listeners.
     */
    stopCamera() {
        if (this.stream) {
            this.stream.getTracks().forEach(track => track.stop());
            this.stream = null;
        }
        if (this.videoElement) {
            this.videoElement.srcObject = null;
            this.videoElement = null;
        }
    }

    /**
     * Capture the current frame from video stream onto a canvas.
     * @returns {HTMLCanvasElement|null} - A new canvas containing the captured image.
     */
    captureFrame() {
        if (!this.videoElement || !this.stream) return null;

        const canvas = document.createElement('canvas');
        
        // Capture at actual video feed dimensions (not CSS size)
        const videoWidth = this.videoElement.videoWidth;
        const videoHeight = this.videoElement.videoHeight;

        if (videoWidth === 0 || videoHeight === 0) return null;

        canvas.width = videoWidth;
        canvas.height = videoHeight;

        const ctx = canvas.getContext('2d');
        
        // Horizontal flip if front-facing camera (usually default on laptops)
        // Check if stream settings indicate 'user' facing mode
        let isFront = false;
        const track = this.stream.getVideoTracks()[0];
        if (track) {
            const settings = track.getSettings();
            if (settings.facingMode === 'user' || (settings.label && settings.label.toLowerCase().includes('front'))) {
                isFront = true;
            }
        }

        if (isFront) {
            ctx.translate(canvas.width, 0);
            ctx.scale(-1, 1);
        }

        ctx.drawImage(this.videoElement, 0, 0, canvas.width, canvas.height);
        
        // Reset transform if we flipped
        if (isFront) {
            ctx.setTransform(1, 0, 0, 1, 0, 0);
        }

        return canvas;
    }
}
