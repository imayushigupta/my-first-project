/**
 * Custom Trie implementation for document indexing and prefix search.
 */

class TrieNode {
    constructor() {
        this.children = {}; // Character -> TrieNode mapping
        this.isWord = false;
        this.documentIds = new Set(); // Set of Document IDs that contain this word
    }
}

export class DocumentTrie {
    constructor() {
        this.root = new TrieNode();
    }

    /**
     * Clean and tokenize text into words.
     * @param {string} text - The input text to tokenize.
     * @returns {string[]} - Array of cleaned words.
     */
    _tokenize(text) {
        if (!text) return [];
        // Extract words (letters, numbers, and apostrophes), lowercase them
        return text.toLowerCase()
            .replace(/[^\w\s']/g, ' ')
            .split(/\s+/)
            .filter(word => word.length > 0);
    }

    /**
     * Insert a word into the Trie, associated with a document ID.
     * @param {string} word - The word to insert.
     * @param {string} docId - The ID of the document.
     */
    _insertWord(word, docId) {
        let node = this.root;
        for (const char of word) {
            if (!node.children[char]) {
                node.children[char] = new TrieNode();
            }
            node = node.children[char];
        }
        node.isWord = true;
        node.documentIds.add(docId);
    }

    /**
     * Index an entire document's text under its document ID.
     * @param {string} docId - Unique ID of the document.
     * @param {string} text - Text content of the document.
     */
    indexDocument(docId, text) {
        const words = this._tokenize(text);
        for (const word of words) {
            this._insertWord(word, docId);
        }
    }

    /**
     * Traverse the Trie to find the node corresponding to a prefix.
     * @param {string} prefix - The prefix to search.
     * @returns {TrieNode|null} - The ending node of the prefix, or null.
     */
    _findNode(prefix) {
        let node = this.root;
        const cleanPrefix = prefix.toLowerCase().trim();
        for (const char of cleanPrefix) {
            if (!node.children[char]) {
                return null;
            }
            node = node.children[char];
        }
        return node;
    }

    /**
     * Search for documents containing words that start with the prefix.
     * @param {string} prefix - The prefix query.
     * @returns {string[]} - Array of document IDs containing matching words.
     */
    search(prefix) {
        if (!prefix || prefix.trim().length === 0) return [];
        
        const node = this._findNode(prefix);
        if (!node) return [];

        // Collect all document IDs in the sub-trie starting from this node
        const results = new Set();
        this._collectDocumentIds(node, results);
        return Array.from(results);
    }

    /**
     * Helper to recursively collect all document IDs from a sub-trie node.
     * @param {TrieNode} node - Starting node.
     * @param {Set<string>} resultsSet - Set to collect docIds.
     */
    _collectDocumentIds(node, resultsSet) {
        if (node.isWord) {
            node.documentIds.forEach(id => resultsSet.add(id));
        }
        for (const char in node.children) {
            this._collectDocumentIds(node.children[char], resultsSet);
        }
    }

    /**
     * Get autocomplete suggestions for a given prefix.
     * @param {string} prefix - The typed prefix.
     * @param {number} limit - Maximum suggestions to return.
     * @returns {string[]} - List of autocomplete suggestions.
     */
    getSuggestions(prefix, limit = 5) {
        const cleanPrefix = prefix.toLowerCase().trim();
        if (cleanPrefix.length === 0) return [];

        const node = this._findNode(cleanPrefix);
        if (!node) return [];

        const suggestions = [];
        this._collectWords(node, cleanPrefix, suggestions, limit);
        return suggestions;
    }

    /**
     * Helper to recursively collect complete words from a node.
     */
    _collectWords(node, currentWord, suggestions, limit) {
        if (suggestions.length >= limit) return;

        if (node.isWord) {
            suggestions.push(currentWord);
        }

        // Search children alphabetically/lexicographically
        const sortedKeys = Object.keys(node.children).sort();
        for (const char of sortedKeys) {
            this._collectWords(node.children[char], currentWord + char, suggestions, limit);
            if (suggestions.length >= limit) break;
        }
    }
}
