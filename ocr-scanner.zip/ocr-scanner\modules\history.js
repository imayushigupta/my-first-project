/**
 * Custom Doubly Linked List node representing an editor history state.
 */
class HistoryNode {
    constructor(imageData, transformState) {
        /**
         * The pixel data snapshot of the canvas.
         * @type {ImageData}
         */
        this.imageData = imageData;

        /**
         * Metadata about the transformation (e.g. rotation, current crop corners, filters)
         * @type {Object}
         */
        this.transformState = JSON.parse(JSON.stringify(transformState || {}));

        /** @type {HistoryNode|null} */
        this.prev = null;
        /** @type {HistoryNode|null} */
        this.next = null;
    }
}

/**
 * Custom Doubly Linked List managing undo/redo canvas history with a capacity limit.
 */
export class CanvasHistory {
    /**
     * @param {number} maxCapacity - Maximum number of states to hold to restrict memory usage.
     */
    constructor(maxCapacity = 20) {
        this.maxCapacity = maxCapacity;
        /** @type {HistoryNode|null} */
        this.head = null;
        /** @type {HistoryNode|null} */
        this.tail = null;
        /** @type {HistoryNode|null} */
        this.current = null; // Pointer to the active history state
        this.size = 0;
    }

    /**
     * Insert a new state. Clears any redo history forward of the current pointer.
     * @param {ImageData} imageData - The canvas pixel data to save.
     * @param {Object} transformState - Transformation metadata (applied filters, crop corners, rotation).
     */
    pushState(imageData, transformState) {
        // Deep copy of ImageData to ensure operations don't mutate history snapshots
        // ImageData uses a Uint8ClampedArray which must be cloned explicitly
        const clampedCopy = new Uint8ClampedArray(imageData.data);
        const imageCopy = new ImageData(clampedCopy, imageData.width, imageData.height);

        const newNode = new HistoryNode(imageCopy, transformState);

        if (!this.head) {
            // Empty list initialization
            this.head = newNode;
            this.tail = newNode;
            this.current = newNode;
            this.size = 1;
            return;
        }

        // If we are in the middle of the history (i.e. we did undo operations),
        // sever the "redo" path ahead of current pointer
        if (this.current !== this.tail) {
            this.tail = this.current;
            this.tail.next = null;
            
            // Re-calculate size
            let count = 0;
            let temp = this.head;
            while (temp) {
                count++;
                if (temp === this.tail) break;
                temp = temp.next;
            }
            this.size = count;
        }

        // Add to tail
        this.tail.next = newNode;
        newNode.prev = this.tail;
        this.tail = newNode;
        this.current = newNode;
        this.size++;

        // Enforce maximum capacity
        if (this.size > this.maxCapacity) {
            this._removeHead();
        }
    }

    /**
     * Helper to remove the oldest element (head) when capacity is exceeded.
     */
    _removeHead() {
        if (!this.head) return;
        
        const oldHead = this.head;
        this.head = this.head.next;
        if (this.head) {
            this.head.prev = null;
        } else {
            this.tail = null; // List became empty
        }
        
        // Sever old references
        oldHead.next = null;
        this.size--;
    }

    /**
     * Move pointer back one step.
     * @returns {HistoryNode|null} The previous state, or null if undo is impossible.
     */
    undo() {
        if (!this.current || !this.current.prev) {
            return null; // Cannot undo
        }
        this.current = this.current.prev;
        return this.current;
    }

    /**
     * Move pointer forward one step.
     * @returns {HistoryNode|null} The next state, or null if redo is impossible.
     */
    redo() {
        if (!this.current || !this.current.next) {
            return null; // Cannot redo
        }
        this.current = this.current.next;
        return this.current;
    }

    /**
     * Check if undo is available.
     * @returns {boolean}
     */
    canUndo() {
        return !!(this.current && this.current.prev);
    }

    /**
     * Check if redo is available.
     * @returns {boolean}
     */
    canRedo() {
        return !!(this.current && this.current.next);
    }

    /**
     * Reset the history entirely.
     */
    clear() {
        this.head = null;
        this.tail = null;
        this.current = null;
        this.size = 0;
    }
}
