/**
 * OCR Engine Interface Module
 * Integrates Tesseract.js (loaded globally via script tag) with progress tracking.
 */

/**
 * Perform Optical Character Recognition on a canvas using Tesseract.js.
 * @param {HTMLCanvasElement} canvas - Canvas containing the image to scan.
 * @param {string} lang - Recognition language (e.g. 'eng', 'spa', 'fra').
 * @param {Function} onProgress - Callback receiving progress info: { status: string, progress: number }
 * @returns {Promise<string>} - The recognized text.
 */
export async function runOCR(canvas, lang = 'eng', onProgress = null) {
    if (!window.Tesseract) {
        throw new Error("Tesseract.js library not loaded. Check internet connection or CDN link.");
    }

    // Helper to send progress updates
    const updateProgress = (status, progress) => {
        if (onProgress) {
            onProgress({ status, progress: Math.round(progress * 100) });
        }
    };

    updateProgress("Initializing OCR engine...", 0.05);

    let worker = null;
    try {
        // Create worker with progress logger
        worker = await window.Tesseract.createWorker(lang, 1, {
            logger: message => {
                if (!message) return;
                
                let friendlyStatus = "Processing...";
                let progress = message.progress || 0;

                switch (message.status) {
                    case 'loading tesseract core':
                        friendlyStatus = "Loading OCR core libraries...";
                        break;
                    case 'loaded tesseract core':
                        friendlyStatus = "Core libraries loaded.";
                        break;
                    case 'initializing api':
                        friendlyStatus = "Initializing language dictionary...";
                        break;
                    case 'initialized api':
                        friendlyStatus = "Dictionary initialized.";
                        break;
                    case 'loading language traineddata':
                        friendlyStatus = `Downloading language data [${lang}]...`;
                        break;
                    case 'loaded language traineddata':
                        friendlyStatus = "Language data loaded.";
                        break;
                    case 'recognizing text':
                        friendlyStatus = "Analyzing and recognizing text...";
                        break;
                    default:
                        friendlyStatus = message.status;
                }

                updateProgress(friendlyStatus, progress);
            }
        });

        updateProgress("Analyzing image layout...", 0.9);
        const result = await worker.recognize(canvas);
        
        updateProgress("OCR complete!", 1.0);
        return result.data.text || "";

    } catch (error) {
        console.error("Tesseract OCR execution error:", error);
        throw error;
    } finally {
        if (worker) {
            try {
                await worker.terminate();
            } catch (err) {
                console.error("Failed to terminate worker", err);
            }
        }
    }
}
