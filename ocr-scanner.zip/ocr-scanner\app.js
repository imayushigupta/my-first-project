/**
 * AuraScan OCR - Main App Controller
 * Orchestrates views, camera controls, manual pixel canvas filters, 
 * draggable SVG crop markers, Tesseract OCR executions, Storage, and Speech synthesis.
 */

import { DocumentTrie } from './modules/trie.js';
import { CanvasHistory } from './modules/history.js';
import { 
    perspectiveWarp, 
    adaptiveThreshold, 
    sobelEdgeDetection, 
    convertToGrayscale,
    autoDetectCorners 
} from './modules/imageProcessor.js';
import { 
    saveDocument, 
    getDocuments, 
    deleteDocument, 
    updateDocument, 
    getStorageStats,
    createThumbnail 
} from './modules/storage.js';
import { CameraController } from './modules/camera.js';
import { TTSEngine } from './modules/tts.js';
import { runOCR } from './modules/ocr.js';

// Global App State
const state = {
    currentView: 'view-scanner',
    selectedImage: null,           // HTMLImageElement of source
    cropCorners: [],               // TL, TR, BR, BL relative to display image (in px)
    warpedCanvas: null,            // Initial un-filtered warped canvas
    activeFilter: 'original',      // 'original', 'grayscale', 'adaptive', 'sobel'
    thresholdSensitivity: 15,      // Bradley-Roth sensitivity percent
    ocrTargetW: 1000,              // Presets (e.g. A4 width)
    ocrTargetH: 1400,              // Presets (e.g. A4 height)
    currentDocument: null,         // Document metadata if saved/opened
    
    // Core Modules Instances
    trie: new DocumentTrie(),
    history: new CanvasHistory(20),
    tts: new TTSEngine(),
    camera: new CameraController()
};

// DOM Elements cache
const dom = {
    // Navigation & Layout
    sidebar: document.getElementById('sidebar'),
    sidebarToggle: document.getElementById('sidebar-toggle'),
    views: document.querySelectorAll('.app-view'),
    navItems: document.querySelectorAll('.sidebar-nav .nav-item'),
    themeBtnDark: document.getElementById('theme-btn-dark'),
    themeBtnLight: document.getElementById('theme-btn-light'),
    storagePercentLabel: document.getElementById('storage-percent-label'),
    storageProgressFill: document.getElementById('storage-progress-fill'),
    storageUsedLabel: document.getElementById('storage-used-lbl'),

    // Scanner selection
    sourceSelectionPanel: document.getElementById('source-selection-panel'),
    fileInput: document.getElementById('file-input'),
    btnOpenCamera: document.getElementById('btn-open-camera'),

    // Live webcam panel
    cameraStreamPanel: document.getElementById('camera-stream-panel'),
    cameraVideo: document.getElementById('camera-video'),
    cameraSelect: document.getElementById('camera-select'),
    btnCancelCamera: document.getElementById('btn-cancel-camera'),
    btnCapture: document.getElementById('btn-capture'),
    cameraFlash: document.getElementById('camera-flash'),

    // Draggable Crop panel
    cropperPanel: document.getElementById('cropper-panel'),
    cropperImage: document.getElementById('cropper-image'),
    markersOverlay: document.getElementById('markers-overlay'),
    markersSvg: document.getElementById('markers-svg'),
    btnAutoCorners: document.getElementById('btn-auto-corners'),
    btnApplyWarp: document.getElementById('btn-apply-warp'),
    btnResetWarp: document.getElementById('btn-reset-warp'),
    handles: {
        tl: document.getElementById('handle-tl'),
        tr: document.getElementById('handle-tr'),
        br: document.getElementById('handle-br'),
        bl: document.getElementById('handle-bl')
    },

    // Editor filter panel
    editorPanel: document.getElementById('editor-panel'),
    editorCanvas: document.getElementById('editor-canvas'),
    btnEditorUndo: document.getElementById('btn-editor-undo'),
    btnEditorRedo: document.getElementById('btn-editor-redo'),
    btnRunOcr: document.getElementById('btn-run-ocr'),
    btnRotateLeft: document.getElementById('btn-rotate-left'),
    btnRotateRight: document.getElementById('btn-rotate-right'),
    adaptiveSliderGroup: document.getElementById('adaptive-slider-group'),
    thresholdSensitivitySlider: document.getElementById('threshold-sensitivity'),
    sensitivityLabelVal: document.getElementById('sensitivity-val'),
    filterButtons: document.querySelectorAll('.filter-btn'),

    // Inspector Results Panel
    docTitleInput: document.getElementById('doc-title-input'),
    docTagsList: document.getElementById('doc-tags-list'),
    btnInspectorCancel: document.getElementById('btn-inspector-cancel'),
    btnInspectorSave: document.getElementById('btn-inspector-save'),
    inspectorCanvas: document.getElementById('inspector-canvas'),
    btnCopyText: document.getElementById('btn-copy-text'),
    btnTtsPlay: document.getElementById('btn-tts-play'),
    btnTtsPause: document.getElementById('btn-tts-pause'),
    btnTtsStop: document.getElementById('btn-tts-stop'),
    ttsSpeedSlider: document.getElementById('tts-speed-slider'),
    ttsSpeedLabel: document.getElementById('tts-speed-lbl'),
    ttsStatusIndicator: document.getElementById('tts-status-indicator'),
    ocrTextarea: document.getElementById('ocr-editor-textarea'),
    charCountLabel: document.getElementById('char-count-lbl'),
    btnExportDropdown: document.getElementById('btn-export-dropdown'),
    exportDropdownMenu: document.getElementById('export-dropdown-menu'),
    btnExportTxt: document.getElementById('btn-export-txt'),
    btnExportPdf: document.getElementById('btn-export-pdf'),
    processedImageDim: document.getElementById('processed-image-dim'),

    // Vault panel
    searchVaultInput: document.getElementById('search-vault-input'),
    btnClearSearch: document.getElementById('btn-clear-search'),
    searchAutocompleteList: document.getElementById('search-autocomplete-list'),
    vaultFilterTags: document.getElementById('vault-filter-tags'),
    historyEmptyState: document.getElementById('history-empty-state'),
    documentsGridLayout: document.getElementById('documents-grid-layout'),
    btnEmptyStateNewScan: document.getElementById('btn-empty-state-new-scan'),

    // Settings panel
    settingsOcrLang: document.getElementById('settings-ocr-lang'),
    presetA4: document.getElementById('preset-a4'),
    presetLetter: document.getElementById('preset-letter'),
    presetCustom: document.getElementById('preset-custom'),
    metricTotalDocs: document.getElementById('metric-total-docs'),
    metricTotalWords: document.getElementById('metric-total-words'),
    storageLargeFill: document.getElementById('storage-large-fill'),
    storageLargeUsedLabel: document.getElementById('storage-large-used-lbl'),
    storageLargeFreeLabel: document.getElementById('storage-large-free-lbl'),
    btnPurgeStorage: document.getElementById('btn-purge-storage'),

    // Loading overlay
    globalLoading: document.getElementById('global-loading'),
    loadingPercent: document.getElementById('loading-percent'),
    loadingTitle: document.getElementById('loading-status-title'),
    loadingDetail: document.getElementById('loading-status-detail'),
    loadingProgressLinear: document.getElementById('loading-progress-linear')
};

// Initialize Application
document.addEventListener('DOMContentLoaded', () => {
    // 1. Initialise Lucide Vector Icons
    lucide.createIcons();

    // 2. Setup View Navigation & UI bindings
    setupNavigation();
    setupThemeToggler();
    setupSettingsPanel();
    
    // 3. Setup Camera stream listeners
    setupCameraController();
    
    // 4. Setup Upload drag & drop
    setupFileUpload();

    // 5. Setup Draggable SVG corner overlays
    setupCropperOverlay();
    
    // 6. Setup Editor Actions (Filters, Undo, Redo, Rotate)
    setupEditorActions();

    // 7. Setup Inspector actions (TTS, Copy, Exports, Title tags, Save)
    setupInspectorActions();

    // 8. Setup Search bar and vault query listings
    setupVaultController();

    // 9. Load initial data from storage
    reloadDocumentDatabase();
});

// View Navigation & Theme Controllers
function setupNavigation() {
    dom.sidebarToggle.addEventListener('click', () => {
        dom.sidebar.classList.toggle('collapsed');
        const icon = dom.sidebarToggle.querySelector('i');
        if (dom.sidebar.classList.contains('collapsed')) {
            icon.setAttribute('data-lucide', 'chevron-right');
        } else {
            icon.setAttribute('data-lucide', 'chevron-left');
        }
        lucide.createIcons();
    });

    dom.navItems.forEach(btn => {
        btn.addEventListener('click', () => {
            const target = btn.getAttribute('data-target');
            switchView(target);
            
            // Highlight sidebar nav item
            dom.navItems.forEach(item => item.classList.remove('active'));
            btn.classList.add('active');
        });
    });

    dom.btnEmptyStateNewScan.addEventListener('click', () => {
        document.getElementById('nav-btn-scan').click();
    });
}

function switchView(viewId) {
    state.currentView = viewId;
    dom.views.forEach(view => {
        if (view.id === viewId) {
            view.classList.add('active');
        } else {
            view.classList.remove('active');
        }
    });

    // Handle view specific tasks
    if (viewId === 'view-history') {
        reloadDocumentDatabase(); // Refresh listing
    } else if (viewId === 'view-settings') {
        refreshSettingsMetrics(); // Refresh storage stats
    }
    
    // Safely stop camera when navigating away from Scanner
    if (viewId !== 'view-scanner') {
        state.camera.stopCamera();
        dom.cameraStreamPanel.classList.add('hidden');
        dom.sourceSelectionPanel.classList.remove('hidden');
    }
    
    // Safely stop text to speech readouts when navigating
    if (viewId !== 'view-inspector') {
        stopSpeechText();
    }
}

function setupThemeToggler() {
    const setDark = () => {
        document.body.classList.remove('light-theme');
        document.body.classList.add('dark-theme');
        dom.themeBtnDark.classList.add('active');
        dom.themeBtnLight.classList.remove('active');
    };
    
    const setLight = () => {
        document.body.classList.remove('dark-theme');
        document.body.classList.add('light-theme');
        dom.themeBtnLight.classList.add('active');
        dom.themeBtnDark.classList.remove('active');
    };

    dom.themeBtnDark.addEventListener('click', setDark);
    dom.themeBtnLight.addEventListener('click', setLight);
}

// Camera Capture Controller
function setupCameraController() {
    dom.btnOpenCamera.addEventListener('click', async () => {
        dom.sourceSelectionPanel.classList.add('hidden');
        dom.cameraStreamPanel.classList.remove('hidden');

        const success = await state.camera.startCamera(dom.cameraVideo);
        if (!success) {
            alert("Unable to access the camera. Check camera permissions or choose Upload file instead.");
            dom.cameraStreamPanel.classList.add('hidden');
            dom.sourceSelectionPanel.classList.remove('hidden');
            return;
        }

        // Enumerate sources
        const devices = await state.camera.getCameras();
        dom.cameraSelect.innerHTML = '';
        devices.forEach(device => {
            const opt = document.createElement('option');
            opt.value = device.id;
            opt.textContent = device.label;
            dom.cameraSelect.appendChild(opt);
        });
    });

    dom.cameraSelect.addEventListener('change', async () => {
        await state.camera.startCamera(dom.cameraVideo, dom.cameraSelect.value);
    });

    dom.btnCancelCamera.addEventListener('click', () => {
        state.camera.stopCamera();
        dom.cameraStreamPanel.classList.add('hidden');
        dom.sourceSelectionPanel.classList.remove('hidden');
    });

    dom.btnCapture.addEventListener('click', () => {
        // Shutter flash animation
        dom.cameraFlash.classList.add('active');
        setTimeout(() => dom.cameraFlash.classList.remove('active'), 400);

        // Render video onto canvas frame
        const capturedCanvas = state.camera.captureFrame();
        if (capturedCanvas) {
            state.camera.stopCamera();
            dom.cameraStreamPanel.classList.add('hidden');
            loadImageIntoCropper(capturedCanvas.toDataURL());
        } else {
            alert("Camera capture failed. Please try again.");
        }
    });
}

// Drag & Drop File Upload Hooks
function setupFileUpload() {
    dom.fileInput.addEventListener('change', (e) => {
        if (e.target.files && e.target.files[0]) {
            const reader = new FileReader();
            reader.onload = (event) => {
                loadImageIntoCropper(event.target.result);
            };
            reader.readAsDataURL(e.target.files[0]);
        }
    });

    // Drag over support
    const uploadCard = document.getElementById('source-card-upload');
    uploadCard.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadCard.style.borderColor = 'var(--accent)';
    });

    uploadCard.addEventListener('dragleave', () => {
        uploadCard.style.borderColor = 'var(--border-color)';
    });

    uploadCard.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadCard.style.borderColor = 'var(--border-color)';
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            const file = e.dataTransfer.files[0];
            if (file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = (event) => {
                    loadImageIntoCropper(event.target.result);
                };
                reader.readAsDataURL(file);
            }
        }
    });
}

// Draggable 4-Point Cropper Setup
function setupCropperOverlay() {
    // Register drag behavior on all 4 corners
    makeDraggable(dom.handles.tl);
    makeDraggable(dom.handles.tr);
    makeDraggable(dom.handles.br);
    makeDraggable(dom.handles.bl);

    // Watch resize to keep handles mapped perfectly on layout change
    window.addEventListener('resize', () => {
        if (state.selectedImage && state.currentView === 'view-scanner') {
            adjustOverlayBoundaries();
        }
    });

    dom.btnAutoCorners.addEventListener('click', () => {
        if (!state.selectedImage) return;
        
        // Auto corner detection using Sobel filter
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = state.selectedImage.naturalWidth;
        tempCanvas.height = state.selectedImage.naturalHeight;
        const ctx = tempCanvas.getContext('2d');
        ctx.drawImage(state.selectedImage, 0, 0);
        
        const imageData = ctx.getImageData(0, 0, tempCanvas.width, tempCanvas.height);
        const corners = autoDetectCorners(imageData);

        // Apply suggestions back
        const w = dom.markersOverlay.clientWidth;
        const h = dom.markersOverlay.clientHeight;
        const natW = state.selectedImage.naturalWidth;
        const natH = state.selectedImage.naturalHeight;

        const setHandlePos = (handle, natPt) => {
            const x = (natPt.x / natW) * w;
            const y = (natPt.y / natH) * h;
            handle.style.left = `${x}px`;
            handle.style.top = `${y}px`;
        };

        setHandlePos(dom.handles.tl, corners[0]);
        setHandlePos(dom.handles.tr, corners[1]);
        setHandlePos(dom.handles.br, corners[2]);
        setHandlePos(dom.handles.bl, corners[3]);

        drawSvgConnectors();
    });

    dom.btnApplyWarp.addEventListener('click', () => {
        if (!state.selectedImage) return;

        // Perform warp calculations
        const w = dom.markersOverlay.clientWidth;
        const h = dom.markersOverlay.clientHeight;
        const natW = state.selectedImage.naturalWidth;
        const natH = state.selectedImage.naturalHeight;

        const getPt = (handle) => ({
            x: parseFloat(handle.style.left) || 0,
            y: parseFloat(handle.style.top) || 0
        });

        // Map layout coordinates to natural image scale
        const scalePt = (pt) => ({
            x: Math.round((pt.x / w) * natW),
            y: Math.round((pt.y / h) * natH)
        });

        const quad = [
            scalePt(getPt(dom.handles.tl)), // TL
            scalePt(getPt(dom.handles.tr)), // TR
            scalePt(getPt(dom.handles.br)), // BR
            scalePt(getPt(dom.handles.bl))  // BL
        ];

        // Draw original raw image onto temp canvas to get base image data
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = natW;
        tempCanvas.height = natH;
        const ctx = tempCanvas.getContext('2d');
        ctx.drawImage(state.selectedImage, 0, 0);
        
        const srcImageData = ctx.getImageData(0, 0, natW, natH);

        // Apply perspective transform
        const warpedImageData = perspectiveWarp(srcImageData, quad, state.ocrTargetW, state.ocrTargetH);

        // Create initial editor canvas
        state.warpedCanvas = document.createElement('canvas');
        state.warpedCanvas.width = state.ocrTargetW;
        state.warpedCanvas.height = state.ocrTargetH;
        const warpedCtx = state.warpedCanvas.getContext('2d');
        warpedCtx.putImageData(warpedImageData, 0, 0);

        // Clear editor state history, push first base state
        state.history.clear();
        state.history.pushState(warpedImageData, { filter: 'original', rotation: 0 });
        state.activeFilter = 'original';

        // Display results in editor frame
        dom.cropperPanel.classList.add('hidden');
        dom.editorPanel.classList.remove('hidden');

        refreshEditorCanvas();
        updateUndoRedoButtonsState();
    });

    dom.btnResetWarp.addEventListener('click', () => {
        resetWarpMarkersDefault();
    });
}

function loadImageIntoCropper(dataUrl) {
    dom.sourceSelectionPanel.classList.add('hidden');
    dom.cropperPanel.classList.remove('hidden');

    state.selectedImage = new Image();
    state.selectedImage.onload = () => {
        dom.cropperImage.src = dataUrl;
        
        // Wait minor delay to ensure container layouts render
        setTimeout(() => {
            adjustOverlayBoundaries();
            resetWarpMarkersDefault();
        }, 100);
    };
    state.selectedImage.src = dataUrl;
}

function adjustOverlayBoundaries() {
    const w = dom.cropperImage.clientWidth;
    const h = dom.cropperImage.clientHeight;
    
    // Size the markers overlay EXACTLY to match client display image boundaries
    dom.markersOverlay.style.width = `${w}px`;
    dom.markersOverlay.style.height = `${h}px`;
    dom.markersOverlay.style.left = `${dom.cropperImage.offsetLeft}px`;
    dom.markersOverlay.style.top = `${dom.cropperImage.offsetTop}px`;
}

function resetWarpMarkersDefault() {
    const w = dom.markersOverlay.clientWidth;
    const h = dom.markersOverlay.clientHeight;

    // Set 15% crop margin padding as default corners
    dom.handles.tl.style.left = `${w * 0.15}px`;
    dom.handles.tl.style.top = `${h * 0.15}px`;

    dom.handles.tr.style.left = `${w * 0.85}px`;
    dom.handles.tr.style.top = `${h * 0.15}px`;

    dom.handles.br.style.left = `${w * 0.85}px`;
    dom.handles.br.style.top = `${h * 0.85}px`;

    dom.handles.bl.style.left = `${w * 0.15}px`;
    dom.handles.bl.style.top = `${h * 0.85}px`;

    drawSvgConnectors();
}

function getHandlePos(corner) {
    const handle = dom.handles[corner];
    return {
        x: parseFloat(handle.style.left) || 0,
        y: parseFloat(handle.style.top) || 0
    };
}

function drawSvgConnectors() {
    const tl = getHandlePos('tl');
    const tr = getHandlePos('tr');
    const br = getHandlePos('br');
    const bl = getHandlePos('bl');

    dom.markersSvg.innerHTML = `
        <line x1="${tl.x}" y1="${tl.y}" x2="${tr.x}" y2="${tr.y}" class="connector-line" />
        <line x1="${tr.x}" y1="${tr.y}" x2="${br.x}" y2="${br.y}" class="connector-line" />
        <line x1="${br.x}" y1="${br.y}" x2="${bl.x}" y2="${bl.y}" class="connector-line" />
        <line x1="${bl.x}" y1="${bl.y}" x2="${tl.x}" y2="${tl.y}" class="connector-line" />
    `;
}

function makeDraggable(handle) {
    const onStart = (e) => {
        e.preventDefault();
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        
        const overlayRect = dom.markersOverlay.getBoundingClientRect();
        
        const startX = parseFloat(handle.style.left) || 0;
        const startY = parseFloat(handle.style.top) || 0;

        const onMove = (moveEvent) => {
            const currentX = moveEvent.touches ? moveEvent.touches[0].clientX : moveEvent.clientX;
            const currentY = moveEvent.touches ? moveEvent.touches[0].clientY : moveEvent.clientY;
            
            const dx = currentX - clientX;
            const dy = currentY - clientY;

            let newX = startX + dx;
            let newY = startY + dy;

            // Constrain within overlay borders
            newX = Math.max(0, Math.min(overlayRect.width, newX));
            newY = Math.max(0, Math.min(overlayRect.height, newY));

            handle.style.left = `${newX}px`;
            handle.style.top = `${newY}px`;

            drawSvgConnectors();
        };

        const onEnd = () => {
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseup', onEnd);
            document.removeEventListener('touchmove', onMove);
            document.removeEventListener('touchend', onEnd);
        };

        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onEnd);
        document.addEventListener('touchmove', onMove, { passive: false });
        document.addEventListener('touchend', onEnd);
    };

    handle.addEventListener('mousedown', onStart);
    handle.addEventListener('touchstart', onStart, { passive: false });
}

// Editor Workspace Controls (Filters, Rotates, Undo/Redo)
function setupEditorActions() {
    dom.filterButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const filter = btn.getAttribute('data-filter');
            applyFilterAndPushHistory(filter);
        });
    });

    dom.thresholdSensitivitySlider.addEventListener('input', (e) => {
        state.thresholdSensitivity = parseInt(e.target.value);
        dom.sensitivityLabelVal.textContent = `${state.thresholdSensitivity}%`;
    });

    // Redraw filter on release of slider to avoid performance lag
    dom.thresholdSensitivitySlider.addEventListener('change', () => {
        if (state.activeFilter === 'adaptive') {
            applyFilterAndPushHistory('adaptive');
        }
    });

    dom.btnRotateLeft.addEventListener('click', () => rotateCanvas(-90));
    dom.btnRotateRight.addEventListener('click', () => rotateCanvas(90));

    dom.btnEditorUndo.addEventListener('click', () => {
        const prevNode = state.history.undo();
        if (prevNode) {
            restoreState(prevNode);
        }
    });

    dom.btnEditorRedo.addEventListener('click', () => {
        const nextNode = state.history.redo();
        if (nextNode) {
            restoreState(nextNode);
        }
    });

    // Run Tesseract OCR engine
    dom.btnRunOcr.addEventListener('click', async () => {
        showLoadingOverlay("Preparing OCR engine...", 0);
        
        try {
            // Get selected language
            const lang = dom.settingsOcrLang.value;
            const text = await runOCR(dom.editorCanvas, lang, (progressInfo) => {
                showLoadingOverlay(progressInfo.status, progressInfo.progress);
            });

            hideLoadingOverlay();
            setupInspectorView(text);

        } catch (e) {
            hideLoadingOverlay();
            alert(`OCR Engine failed: ${e.message}. Double check internet connection for language downloading.`);
        }
    });
}

function applyFilterAndPushHistory(filterType) {
    dom.filterButtons.forEach(btn => {
        if (btn.getAttribute('data-filter') === filterType) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });

    state.activeFilter = filterType;
    if (filterType === 'adaptive') {
        dom.adaptiveSliderGroup.classList.remove('hidden');
    } else {
        dom.adaptiveSliderGroup.classList.add('hidden');
    }

    const baseState = state.history.current;
    if (!baseState) return;

    // Render new filter calculations on the base imageData
    const newImgData = computeFilteredImageData(baseState.imageData, filterType);
    
    // Save to Doubly Linked List
    state.history.pushState(newImgData, { filter: filterType, rotation: baseState.transformState.rotation });
    
    refreshEditorCanvas();
    updateUndoRedoButtonsState();
}

function rotateCanvas(degrees) {
    const activeHistoryNode = state.history.current;
    if (!activeHistoryNode) return;

    const srcImgData = activeHistoryNode.imageData;
    const w = srcImgData.width;
    const h = srcImgData.height;

    // Create rotated canvas dimensions
    const rotCanvas = document.createElement('canvas');
    rotCanvas.width = (degrees === 90 || degrees === -90) ? h : w;
    rotCanvas.height = (degrees === 90 || degrees === -90) ? w : h;
    const rCtx = rotCanvas.getContext('2d');

    // Perform rotation transformation matrix
    rCtx.translate(rotCanvas.width / 2, rotCanvas.height / 2);
    rCtx.rotate((degrees * Math.PI) / 180);
    
    // Draw original pixels back
    const temp = document.createElement('canvas');
    temp.width = w;
    temp.height = h;
    temp.getContext('2d').putImageData(srcImgData, 0, 0);
    
    rCtx.drawImage(temp, -w / 2, -h / 2);
    
    const rotatedImgData = rCtx.getImageData(0, 0, rotCanvas.width, rotCanvas.height);
    
    // Calculate new rotation state metadata
    const prevRot = activeHistoryNode.transformState.rotation || 0;
    const newRot = (prevRot + degrees) % 360;

    state.history.pushState(rotatedImgData, { filter: state.activeFilter, rotation: newRot });
    
    refreshEditorCanvas();
    updateUndoRedoButtonsState();
}

function computeFilteredImageData(baseImageData, filterType) {
    // Create new buffer copy
    const canvas = document.createElement('canvas');
    canvas.width = baseImageData.width;
    canvas.height = baseImageData.height;
    const ctx = canvas.getContext('2d');
    ctx.putImageData(baseImageData, 0, 0);

    const targetImageData = ctx.getImageData(0, 0, canvas.width, canvas.height);

    switch (filterType) {
        case 'grayscale':
            return convertToGrayscale(targetImageData);
        case 'adaptive':
            return adaptiveThreshold(targetImageData, state.thresholdSensitivity);
        case 'sobel':
            return sobelEdgeDetection(targetImageData);
        case 'original':
        default:
            return targetImageData; // Returns un-filtered warped image
    }
}

function restoreState(historyNode) {
    state.activeFilter = historyNode.transformState.filter || 'original';
    
    // Update filter buttons UI
    dom.filterButtons.forEach(btn => {
        if (btn.getAttribute('data-filter') === state.activeFilter) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });

    if (state.activeFilter === 'adaptive') {
        dom.adaptiveSliderGroup.classList.remove('hidden');
    } else {
        dom.adaptiveSliderGroup.classList.add('hidden');
    }

    refreshEditorCanvas();
    updateUndoRedoButtonsState();
}

function refreshEditorCanvas() {
    const activeNode = state.history.current;
    if (!activeNode) return;

    dom.editorCanvas.width = activeNode.imageData.width;
    dom.editorCanvas.height = activeNode.imageData.height;
    const ctx = dom.editorCanvas.getContext('2d');
    ctx.putImageData(activeNode.imageData, 0, 0);
}

function updateUndoRedoButtonsState() {
    dom.btnEditorUndo.disabled = !state.history.canUndo();
    dom.btnEditorRedo.disabled = !state.history.canRedo();
}

// Global Loading Overlay controllers
function showLoadingOverlay(title, percent) {
    dom.globalLoading.classList.remove('hidden');
    dom.loadingTitle.textContent = title;
    dom.loadingPercent.textContent = `${percent}%`;
    dom.loadingProgressLinear.style.width = `${percent}%`;
}

function hideLoadingOverlay() {
    dom.globalLoading.classList.add('hidden');
}

// Inspector split-screen results panel logic
function setupInspectorView(extractedText) {
    switchView('view-inspector');

    // Render edited canvas to inspector left side view
    dom.inspectorCanvas.width = dom.editorCanvas.width;
    dom.inspectorCanvas.height = dom.editorCanvas.height;
    dom.inspectorCanvas.getContext('2d').drawImage(dom.editorCanvas, 0, 0);
    dom.processedImageDim.textContent = `${dom.editorCanvas.width} x ${dom.editorCanvas.height} px`;

    // Populate editable items
    const today = new Date().toISOString().slice(0, 10);
    dom.docTitleInput.value = `Scan ${today} ${new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}`;
    dom.ocrTextarea.value = extractedText;
    
    // Initialize tags
    document.querySelectorAll('.tag-badge-select').forEach(badge => {
        badge.classList.remove('active');
    });

    // Reset speech synth controls
    stopSpeechText();
    updateCharCounter();
    state.currentDocument = null; // Mark as fresh/new
}

function updateCharCounter() {
    const text = dom.ocrTextarea.value;
    const chars = text.length;
    const words = text.trim() === "" ? 0 : text.trim().split(/\s+/).length;
    dom.charCountLabel.textContent = `${chars} characters | ${words} words`;
}

function setupInspectorActions() {
    dom.ocrTextarea.addEventListener('input', updateCharCounter);

    // Bind document tag selections (multi-select allowed)
    document.querySelectorAll('.tag-badge-select').forEach(badge => {
        badge.addEventListener('click', () => {
            badge.classList.toggle('active');
        });
    });

    dom.btnInspectorCancel.addEventListener('click', () => {
        if (confirm("Discard this document? All current scan and OCR progress will be lost.")) {
            switchView('view-scanner');
            resetScannerWorkspace();
        }
    });

    dom.btnInspectorSave.addEventListener('click', async () => {
        const title = dom.docTitleInput.value.trim() || 'Untitled Document';
        const text = dom.ocrTextarea.value;
        
        // Collect selected tag badges
        const tags = [];
        document.querySelectorAll('.tag-badge-select.active').forEach(badge => {
            tags.push(badge.getAttribute('data-tag'));
        });

        // Create compressed thumbnail
        const thumbDataUrl = await createThumbnail(dom.inspectorCanvas, 150, 0.4);

        const docPayload = {
            id: state.currentDocument ? state.currentDocument.id : null,
            title,
            text,
            tags,
            thumbnail: thumbDataUrl,
            date: state.currentDocument ? state.currentDocument.date : new Date().toISOString()
        };

        const saved = saveDocument(docPayload);
        
        // Index inside the custom Trie search prefix tree
        state.trie.indexDocument(saved.id, text);
        state.trie.indexDocument(saved.id, title); // Also index keywords inside title

        alert("Document saved successfully!");
        switchView('view-history');
        resetScannerWorkspace();
    });

    // Copy to clipboard
    dom.btnCopyText.addEventListener('click', () => {
        const text = dom.ocrTextarea.value;
        navigator.clipboard.writeText(text).then(() => {
            const icon = dom.btnCopyText.querySelector('i');
            icon.setAttribute('data-lucide', 'check');
            dom.btnCopyText.style.borderColor = 'var(--success)';
            dom.btnCopyText.style.color = 'var(--success)';
            lucide.createIcons();

            setTimeout(() => {
                icon.setAttribute('data-lucide', 'copy');
                dom.btnCopyText.style.borderColor = 'var(--border-color)';
                dom.btnCopyText.style.color = 'var(--text-secondary)';
                lucide.createIcons();
            }, 2000);
        }).catch(err => {
            console.error("Copy failed", err);
        });
    });

    // TTS Actions
    dom.btnTtsPlay.addEventListener('click', () => {
        const text = dom.ocrTextarea.value;
        const rate = parseFloat(dom.ttsSpeedSlider.value);
        const lang = dom.settingsOcrLang.value;

        if (state.tts.isPaused()) {
            state.tts.resume();
            toggleTtsButtons(true);
        } else {
            state.tts.speak(
                text, 
                lang, 
                rate, 
                () => toggleTtsButtons(true), // onStart
                () => toggleTtsButtons(false) // onEnd
            );
        }
    });

    dom.btnTtsPause.addEventListener('click', () => {
        state.tts.pause();
        dom.btnTtsPause.classList.add('hidden');
        dom.btnTtsPlay.classList.remove('hidden');
        dom.ttsStatusIndicator.classList.add('hidden');
    });

    dom.btnTtsStop.addEventListener('click', () => {
        stopSpeechText();
    });

    dom.ttsSpeedSlider.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        dom.ttsSpeedLabel.textContent = `${val}x`;
    });

    // Export dropdown toggle
    dom.btnExportDropdown.addEventListener('click', (e) => {
        e.stopPropagation();
        dom.exportDropdownMenu.classList.toggle('hidden');
    });

    document.addEventListener('click', () => {
        dom.exportDropdownMenu.classList.add('hidden');
    });

    // Export Text (.txt) file download
    dom.btnExportTxt.addEventListener('click', () => {
        const text = dom.ocrTextarea.value;
        const title = dom.docTitleInput.value.trim() || 'scanned-document';
        const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `${title.toLowerCase().replace(/[^a-z0-9]/g, '_')}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    });

    // Export PDF (.pdf) file download utilizing jsPDF with auto-pagination
    dom.btnExportPdf.addEventListener('click', () => {
        const text = dom.ocrTextarea.value;
        const title = dom.docTitleInput.value.trim() || 'Scanned Document';

        const { jsPDF } = window.jspdf;
        const pdf = new jsPDF();
        
        // Define margins and layout limits
        const marginX = 20;
        let currentY = 30;
        const pageHeight = pdf.internal.pageSize.getHeight();
        const pageW = pdf.internal.pageSize.getWidth();

        // 1. Render Header / Title banner
        pdf.setFont("helvetica", "bold");
        pdf.setFontSize(18);
        pdf.setTextColor(98, 0, 238); // Aura Violet primary
        pdf.text("AuraScan Document PDF Export", marginX, 20);

        pdf.setDrawColor(200, 200, 200);
        pdf.line(marginX, 24, pageW - marginX, 24);

        // Meta header info
        pdf.setFont("helvetica", "normal");
        pdf.setFontSize(10);
        pdf.setTextColor(100, 100, 100);
        pdf.text(`Document Title: ${title}`, marginX, currentY);
        pdf.text(`Date Exported: ${new Date().toLocaleDateString()}`, pageW - marginX - 60, currentY);
        
        currentY += 15;

        // 2. Render Text Paragraphs
        pdf.setFont("helvetica", "normal");
        pdf.setFontSize(11);
        pdf.setTextColor(30, 30, 30);
        
        // Auto-wrap text lines relative to margins
        const maxTextWidth = pageW - (marginX * 2);
        const wrappedLines = pdf.splitTextToSize(text, maxTextWidth);

        for (let i = 0; i < wrappedLines.length; i++) {
            // Check page overflow boundaries
            if (currentY + 8 > pageHeight - 20) {
                pdf.addPage();
                currentY = 20; // reset y offset on new page
            }
            pdf.text(wrappedLines[i], marginX, currentY);
            currentY += 7; // Line spacing
        }

        // Save file
        pdf.save(`${title.toLowerCase().replace(/[^a-z0-9]/g, '_')}.pdf`);
    });
}

function toggleTtsButtons(isPlaying) {
    if (isPlaying) {
        dom.btnTtsPlay.classList.add('hidden');
        dom.btnTtsPause.classList.remove('hidden');
        dom.ttsStatusIndicator.classList.remove('hidden');
    } else {
        dom.btnTtsPlay.classList.remove('hidden');
        dom.btnTtsPause.classList.add('hidden');
        dom.ttsStatusIndicator.classList.add('hidden');
    }
}

function stopSpeechText() {
    state.tts.stop();
    toggleTtsButtons(false);
}

function resetScannerWorkspace() {
    state.selectedImage = null;
    state.cropCorners = [];
    state.warpedCanvas = null;
    state.activeFilter = 'original';
    
    // Clear elements
    dom.cropperImage.src = '';
    dom.cropperPanel.classList.add('hidden');
    dom.editorPanel.classList.add('hidden');
    dom.sourceSelectionPanel.classList.remove('hidden');
    dom.fileInput.value = '';

    const editorCtx = dom.editorCanvas.getContext('2d');
    editorCtx.clearRect(0, 0, dom.editorCanvas.width, dom.editorCanvas.height);
}

// Document History Vault Manager
function setupVaultController() {
    // Search vault keyups listener
    dom.searchVaultInput.addEventListener('keyup', () => {
        filterAndRenderDocumentsGrid();
    });

    // Focus toggles for autocomplete suggestions
    dom.searchVaultInput.addEventListener('focus', () => {
        renderAutocompleteSuggestions();
    });

    dom.searchVaultInput.addEventListener('input', () => {
        renderAutocompleteSuggestions();
    });

    // Close suggestions dropdown when clicking outside
    document.addEventListener('click', (e) => {
        if (!dom.searchBarContainer || !dom.searchBarContainer.contains(e.target)) {
            dom.searchAutocompleteList.classList.add('hidden');
        }
    });
    
    dom.searchBarContainer = document.querySelector('.search-bar-container');

    dom.btnClearSearch.addEventListener('click', () => {
        dom.searchVaultInput.value = '';
        dom.btnClearSearch.classList.add('hidden');
        dom.searchAutocompleteList.classList.add('hidden');
        filterAndRenderDocumentsGrid();
    });

    // Vault category tags filtering clicks
    document.querySelectorAll('.tag-filter-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.tag-filter-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            filterAndRenderDocumentsGrid();
        });
    });
}

function reloadDocumentDatabase() {
    const docs = getDocuments();
    
    // Clear and re-populate Trie index structure
    state.trie = new DocumentTrie();
    docs.forEach(doc => {
        state.trie.indexDocument(doc.id, doc.text);
        state.trie.indexDocument(doc.id, doc.title);
    });

    filterAndRenderDocumentsGrid();
    updateGlobalMetricsPanel();
}

function filterAndRenderDocumentsGrid() {
    const allDocs = getDocuments();
    let query = dom.searchVaultInput.value.trim().toLowerCase();
    
    // Display clear button if query is active
    if (query.length > 0) {
        dom.btnClearSearch.classList.remove('hidden');
    } else {
        dom.btnClearSearch.classList.add('hidden');
    }

    // 1. Category Tag filtering
    const activeTagBtn = document.querySelector('.tag-filter-btn.active');
    const selectedFilterTag = activeTagBtn ? activeTagBtn.getAttribute('data-tag') : 'ALL';
    
    let filtered = allDocs;
    if (selectedFilterTag !== 'ALL') {
        filtered = filtered.filter(doc => doc.tags && doc.tags.includes(selectedFilterTag));
    }

    // 2. Trie Search indexing filter
    if (query.length > 0) {
        // Query Trie to get matching document IDs
        const matchedDocIds = state.trie.search(query);
        
        // Also perform simple substring search on title/text as a fallback
        filtered = filtered.filter(doc => {
            const matchesTrie = matchedDocIds.includes(doc.id);
            const matchesSubstring = doc.title.toLowerCase().includes(query) || doc.text.toLowerCase().includes(query);
            return matchesTrie || matchesSubstring;
        });
    }

    // 3. Render grid outputs
    dom.documentsGridLayout.innerHTML = '';
    
    if (filtered.length === 0) {
        dom.historyEmptyState.classList.remove('hidden');
        dom.documentsGridLayout.classList.add('hidden');
        return;
    }

    dom.historyEmptyState.classList.add('hidden');
    dom.documentsGridLayout.classList.remove('hidden');

    filtered.forEach(doc => {
        const card = createDocumentCardElement(doc);
        dom.documentsGridLayout.appendChild(card);
    });

    // Re-initialize any dynamic Lucide icons inside card nodes
    lucide.createIcons();
}

function createDocumentCardElement(doc) {
    const card = document.createElement('div');
    card.className = 'doc-card';
    card.setAttribute('data-id', doc.id);

    const dateFormatted = new Date(doc.date).toLocaleDateString(undefined, {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });

    const snippetText = doc.text.substring(0, 120) + (doc.text.length > 120 ? '...' : '');
    const wordsCount = doc.text.trim() === "" ? 0 : doc.text.trim().split(/\s+/).length;

    // Build tags string
    const firstTag = doc.tags && doc.tags[0] ? doc.tags[0] : 'Note';

    card.innerHTML = `
        <div class="doc-card-thumbnail-container">
            ${doc.thumbnail ? `<img src="${doc.thumbnail}" class="doc-card-thumb" alt="document preview">` : `<div class="doc-card-thumb-placeholder"><i data-lucide="file-text"></i></div>`}
            <span class="doc-card-tag-floating">${firstTag}</span>
        </div>
        <div class="doc-card-body">
            <span class="doc-card-date">${dateFormatted}</span>
            <h4 class="doc-card-title">${doc.title}</h4>
            <p class="doc-card-snippet">${doc.text ? snippetText : '<i>Empty Text</i>'}</p>
        </div>
        <div class="doc-card-footer">
            <span class="doc-card-words">${wordsCount} words</span>
            <div class="doc-card-actions">
                <button class="btn-icon btn-card-edit" title="Edit Document">
                    <i data-lucide="edit-3"></i>
                </button>
                <button class="btn-icon btn-card-delete" title="Delete Document">
                    <i data-lucide="trash-2" style="color: var(--danger)"></i>
                </button>
            </div>
        </div>
    `;

    // Bind card operations
    card.querySelector('.btn-card-edit').addEventListener('click', () => {
        openDocumentInInspector(doc);
    });

    card.querySelector('.btn-card-delete').addEventListener('click', () => {
        if (confirm(`Delete document "${doc.title}"?`)) {
            deleteDocument(doc.id);
            reloadDocumentDatabase();
        }
    });

    return card;
}

function openDocumentInInspector(doc) {
    state.currentDocument = doc;
    switchView('view-inspector');

    // Load thumbnail or empty canvas
    const img = new Image();
    img.onload = () => {
        dom.inspectorCanvas.width = img.width;
        dom.inspectorCanvas.height = img.height;
        const ctx = dom.inspectorCanvas.getContext('2d');
        ctx.drawImage(img, 0, 0);
        dom.processedImageDim.textContent = `${img.width} x ${img.height} px`;
    };
    img.src = doc.thumbnail || '';

    // Populate title, tags and text
    dom.docTitleInput.value = doc.title;
    dom.ocrTextarea.value = doc.text;

    document.querySelectorAll('.tag-badge-select').forEach(badge => {
        const tag = badge.getAttribute('data-tag');
        if (doc.tags && doc.tags.includes(tag)) {
            badge.classList.add('active');
        } else {
            badge.classList.remove('active');
        }
    });

    updateCharCounter();
    stopSpeechText();
}

function renderAutocompleteSuggestions() {
    const val = dom.searchVaultInput.value.trim().toLowerCase();
    if (val.length === 0) {
        dom.searchAutocompleteList.classList.add('hidden');
        return;
    }

    // Query Trie for suggestions
    const matches = state.trie.getSuggestions(val, 5);

    if (matches.length === 0) {
        dom.searchAutocompleteList.classList.add('hidden');
        return;
    }

    dom.searchAutocompleteList.innerHTML = '';
    dom.searchAutocompleteList.classList.remove('hidden');

    matches.forEach(word => {
        const item = document.createElement('div');
        item.className = 'autocomplete-item';
        item.innerHTML = `<i data-lucide="history" class="small-icon"></i><span>${word}</span>`;
        item.addEventListener('click', () => {
            dom.searchVaultInput.value = word;
            dom.searchAutocompleteList.classList.add('hidden');
            filterAndRenderDocumentsGrid();
        });
        dom.searchAutocompleteList.appendChild(item);
    });

    lucide.createIcons();
}

// Sidebar & Settings Dashboard metrics indicators
function updateGlobalMetricsPanel() {
    const stats = getStorageStats();
    
    // KB values
    const usedKb = (stats.usedBytes / 1024).toFixed(1);
    
    dom.storagePercentLabel.textContent = `${stats.percentUsed.toFixed(1)}%`;
    dom.storageProgressFill.style.width = `${stats.percentUsed}%`;
    dom.storageUsedLabel.textContent = `${usedKb} KB / 5 MB`;

    // Style adjustments for storage warning
    if (stats.percentUsed > 80) {
        dom.storageProgressFill.style.background = 'var(--danger)';
    } else {
        dom.storageProgressFill.style.background = 'var(--accent)';
    }
}

function setupSettingsPanel() {
    // Layout presets bindings
    const handlePresetChange = (btn, w, h) => {
        document.querySelectorAll('.aspect-preset-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        state.ocrTargetW = w;
        state.ocrTargetH = h;
    };

    dom.presetA4.addEventListener('click', () => handlePresetChange(dom.presetA4, 1000, 1400));
    dom.presetLetter.addEventListener('click', () => handlePresetChange(dom.presetLetter, 1200, 1600));
    dom.presetCustom.addEventListener('click', () => handlePresetChange(dom.presetCustom, 800, 1000));

    // Clear database purge handler
    dom.btnPurgeStorage.addEventListener('click', () => {
        if (confirm("CRITICAL WARNING: This will permanently delete all your scanned files and search indices. Do you want to proceed?")) {
            localStorage.clear();
            reloadDocumentDatabase();
            alert("Database successfully wiped.");
            switchView('view-scanner');
        }
    });
}

function refreshSettingsMetrics() {
    const docs = getDocuments();
    
    // Total docs count
    dom.metricTotalDocs.textContent = docs.length;

    // Total words count
    let totalWords = 0;
    docs.forEach(doc => {
        totalWords += doc.text.trim() === "" ? 0 : doc.text.trim().split(/\s+/).length;
    });
    dom.metricTotalWords.textContent = totalWords;

    // Storage detailed breakdowns
    const stats = getStorageStats();
    const usedKb = (stats.usedBytes / 1024).toFixed(1);
    const freeKb = ((stats.totalLimitBytes - stats.usedBytes) / 1024).toFixed(1);

    dom.storageLargeUsedLabel.textContent = `Used: ${usedKb} KB`;
    dom.storageLargeFreeLabel.textContent = `Free: ${freeKb} KB`;
    dom.storageLargeFill.style.width = `${stats.percentUsed}%`;
}
