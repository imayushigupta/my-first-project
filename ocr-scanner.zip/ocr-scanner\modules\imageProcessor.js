/**
 * Custom Image Processing Engine
 * Implements pixel-level image processing algorithms for canvas:
 * - Grayscale
 * - Sobel Edge Detection
 * - Bradley-Roth Adaptive Thresholding (O(N) via Integral Images)
 * - 4-Point Perspective Warp (Homography Solver & Bilinear Interpolation)
 * - Auto Corner Detection Heuristic
 */

/**
 * Solve a system of linear equations Ax = b using Gaussian Elimination with partial pivoting.
 * @param {number[][]} A - 8x8 coefficient matrix
 * @param {number[]} b - 8x1 result vector
 * @returns {number[]|null} - 8x1 solution vector or null if singular
 */
export function gaussianElimination(A, b) {
    const n = A.length;
    // Create augmented matrix [A|b]
    const M = new Array(n);
    for (let i = 0; i < n; i++) {
        M[i] = new Float64Array(n + 1);
        for (let j = 0; j < n; j++) {
            M[i][j] = A[i][j];
        }
        M[i][n] = b[i];
    }

    for (let i = 0; i < n; i++) {
        // Search for maximum in this column (partial pivoting)
        let maxEl = Math.abs(M[i][i]);
        let maxRow = i;
        for (let k = i + 1; k < n; k++) {
            if (Math.abs(M[k][i]) > maxEl) {
                maxEl = Math.abs(M[k][i]);
                maxRow = k;
            }
        }

        // Swap maximum row with current row
        if (maxRow !== i) {
            const temp = M[i];
            M[i] = M[maxRow];
            M[maxRow] = temp;
        }

        // Make all rows below this one 0 in current column
        if (Math.abs(M[i][i]) < 1e-10) {
            return null; // Singular matrix (collinear points, etc.)
        }

        for (let k = i + 1; k < n; k++) {
            const c = -M[k][i] / M[i][i];
            for (let j = i; j <= n; j++) {
                if (i === j) {
                    M[k][j] = 0;
                } else {
                    M[k][j] += c * M[i][j];
                }
            }
        }
    }

    // Solve equation Ax=b for an upper triangular matrix (back substitution)
    const x = new Float64Array(n);
    for (let i = n - 1; i >= 0; i--) {
        x[i] = M[i][n] / M[i][i];
        for (let k = i - 1; k >= 0; k--) {
            M[k][n] -= M[k][i] * x[i];
        }
    }
    return Array.from(x);
}

/**
 * Calculates the Homography Matrix mapping target (output) rectangle to source (input) quad.
 * This is used for backward mapping (destination -> source) to avoid gaps.
 * @param {Array<{x: number, y: number}>} srcQuad - 4 points representing the selected document corners (TL, TR, BR, BL)
 * @param {number} dstW - Target width
 * @param {number} dstH - Target height
 * @returns {number[]|null} - 8 homography coefficients (h0..h7, h8=1), or null
 */
export function calculateHomography(srcQuad, dstW, dstH) {
    // Destination rectangle corners in clockwise order starting TL
    const dstQuad = [
        { x: 0, y: 0 },
        { x: dstW, y: 0 },
        { x: dstW, y: dstH },
        { x: 0, y: dstH }
    ];

    // We solve for mapping dst -> src (so we can loop over output pixels and find source pixels)
    // u = dst.x, v = dst.y (input to equations)
    // x = src.x, y = src.y (output of equations)
    // x = (h0*u + h1*v + h2) / (h6*u + h7*v + 1)
    // y = (h3*u + h4*v + h5) / (h6*u + h7*v + 1)
    //
    // => h0*u + h1*v + h2 - h6*u*x - h7*v*x = x
    // => h3*u + h4*v + h5 - h6*u*y - h7*v*y = y

    const A = [];
    const b = [];

    for (let i = 0; i < 4; i++) {
        const u = dstQuad[i].x;
        const v = dstQuad[i].y;
        const x = srcQuad[i].x;
        const y = srcQuad[i].y;

        A.push([u, v, 1, 0, 0, 0, -u * x, -v * x]);
        b.push(x);

        A.push([0, 0, 0, u, v, 1, -u * y, -v * y]);
        b.push(y);
    }

    return gaussianElimination(A, b);
}

/**
 * Perform perspective warp on canvas image data.
 * @param {ImageData} srcImageData - Source image data
 * @param {Array<{x: number, y: number}>} srcQuad - Selected TL, TR, BR, BL coordinates
 * @param {number} dstW - Selected output width
 * @param {number} dstH - Selected output height
 * @returns {ImageData} - Warped image data
 */
export function perspectiveWarp(srcImageData, srcQuad, dstW, dstH) {
    const srcW = srcImageData.width;
    const srcH = srcImageData.height;
    const srcData = srcImageData.data;

    // Create target image data buffer
    const dstImageData = new ImageData(dstW, dstH);
    const dstData = dstImageData.data;

    const h = calculateHomography(srcQuad, dstW, dstH);
    if (!h) {
        // If math fails, return a white empty sheet
        dstData.fill(255);
        return dstImageData;
    }

    // Homography coefficients
    const [h0, h1, h2, h3, h4, h5, h6, h7] = h;

    // Backward mapping: Loop through output pixels
    for (let v = 0; v < dstH; v++) {
        for (let u = 0; u < dstW; u++) {
            // Project output coordinate (u, v) back to source coordinate (x, y)
            const denominator = h6 * u + h7 * v + 1;
            const x = (h0 * u + h1 * v + h2) / denominator;
            const y = (h3 * u + h4 * v + h5) / denominator;

            const dstIndex = (v * dstW + u) * 4;

            // Out of bounds check
            if (x < 0 || x >= srcW - 1 || y < 0 || y >= srcH - 1) {
                // Out of boundary -> Set to white background
                dstData[dstIndex] = 255;
                dstData[dstIndex + 1] = 255;
                dstData[dstIndex + 2] = 255;
                dstData[dstIndex + 3] = 255;
                continue;
            }

            // Bilinear Interpolation
            const xf = Math.floor(x);
            const xc = xf + 1;
            const yf = Math.floor(y);
            const yc = yf + 1;

            const dx = x - xf;
            const dy = y - yf;

            const w11 = (1 - dx) * (1 - dy);
            const w21 = dx * (1 - dy);
            const w12 = (1 - dx) * dy;
            const w22 = dx * dy;

            const idx11 = (yf * srcW + xf) * 4;
            const idx21 = (yf * srcW + xc) * 4;
            const idx12 = (yc * srcW + xf) * 4;
            const idx22 = (yc * srcW + xc) * 4;

            // Interpolate Red, Green, Blue
            for (let c = 0; c < 3; c++) {
                dstData[dstIndex + c] = Math.round(
                    srcData[idx11 + c] * w11 +
                    srcData[idx21 + c] * w21 +
                    srcData[idx12 + c] * w12 +
                    srcData[idx22 + c] * w22
                );
            }
            dstData[dstIndex + 3] = 255; // Alpha
        }
    }

    return dstImageData;
}

/**
 * Convert ImageData to Grayscale in place or return a new one.
 * @param {ImageData} imageData - Input ImageData
 * @returns {ImageData} - Grayscale ImageData
 */
export function convertToGrayscale(imageData) {
    const data = imageData.data;
    const len = data.length;
    for (let i = 0; i < len; i += 4) {
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];
        // Luminosity method
        const gray = Math.round(0.299 * r + 0.587 * g + 0.114 * b);
        data[i] = gray;
        data[i + 1] = gray;
        data[i + 2] = gray;
    }
    return imageData;
}

/**
 * Apply Bradley-Roth Adaptive Thresholding.
 * Perfect for correcting shadow and uneven illumination on papers.
 * @param {ImageData} imageData - Grayscale input ImageData
 * @param {number} sensitivity - Percentage of threshold relative to local average (0 to 100, default 15)
 * @param {number} windowRatio - Ratio of image width to window size (default 8)
 * @returns {ImageData} - Binary B&W ImageData
 */
export function adaptiveThreshold(imageData, sensitivity = 15, windowRatio = 8) {
    const w = imageData.width;
    const h = imageData.height;
    
    // First ensure we have a grayscale representation
    // Create a copy of the pixel buffer
    const grayBuffer = new Uint8ClampedArray(w * h);
    const data = imageData.data;
    for (let i = 0; i < data.length; i += 4) {
        const idx = i / 4;
        // Calculate grayscale value
        grayBuffer[idx] = Math.round(0.299 * data[i] + 0.587 * data[i+1] + 0.114 * data[i+2]);
    }

    // Compute Integral Image (Sum Table)
    // S[x, y] is the sum of pixels in rectangle from (0,0) to (x,y)
    const integral = new Float64Array(w * h);
    for (let y = 0; y < h; y++) {
        let lineSum = 0;
        for (let x = 0; x < w; x++) {
            const idx = y * w + x;
            lineSum += grayBuffer[idx];
            if (y === 0) {
                integral[idx] = lineSum;
            } else {
                integral[idx] = integral[(y - 1) * w + x] + lineSum;
            }
        }
    }

    // Set local window parameters
    const s = Math.round(w / windowRatio); // local neighborhood size (width / ratio)
    const halfS = Math.round(s / 2);
    const t = (100 - sensitivity) / 100; // threshold modifier

    const output = new ImageData(w, h);
    const outData = output.data;

    // Binarize using integral image queries
    for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
            const idx = y * w + x;
            
            // Find window boundaries
            const x1 = Math.max(0, x - halfS);
            const x2 = Math.min(w - 1, x + halfS);
            const y1 = Math.max(0, y - halfS);
            const y2 = Math.min(h - 1, y + halfS);

            const count = (x2 - x1 + 1) * (y2 - y1 + 1);

            // Compute sum of local window using integral image
            // Sum = S(x2, y2) - S(x1-1, y2) - S(x2, y1-1) + S(x1-1, y1-1)
            let sum = integral[y2 * w + x2];
            if (x1 > 0) {
                sum -= integral[y2 * w + (x1 - 1)];
            }
            if (y1 > 0) {
                sum -= integral[(y1 - 1) * w + x2];
            }
            if (x1 > 0 && y1 > 0) {
                sum += integral[(y1 - 1) * w + (x1 - 1)];
            }

            const pixelVal = grayBuffer[idx];
            const avg = sum / count;
            const dstIdx = idx * 4;

            // Binarization decision
            if (pixelVal < avg * t) {
                // Dark pixel -> Text (Black)
                outData[dstIdx] = 0;
                outData[dstIdx + 1] = 0;
                outData[dstIdx + 2] = 0;
            } else {
                // Light pixel -> Background (White)
                outData[dstIdx] = 255;
                outData[dstIdx + 1] = 255;
                outData[dstIdx + 2] = 255;
            }
            outData[dstIdx + 3] = 255; // Alpha
        }
    }

    return output;
}

/**
 * Apply Sobel Filter for Edge Detection.
 * Calculates gradients and returns edge map.
 * @param {ImageData} imageData - Input ImageData
 * @returns {ImageData} - Edges rendered in grayscale
 */
export function sobelEdgeDetection(imageData) {
    const w = imageData.width;
    const h = imageData.height;
    const data = imageData.data;

    // Grayscale values
    const gray = new Uint8ClampedArray(w * h);
    for (let i = 0; i < data.length; i += 4) {
        gray[i / 4] = Math.round(0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2]);
    }

    const output = new ImageData(w, h);
    const outData = output.data;

    // Sobel Kernels
    // Kx = [[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]]
    // Ky = [[-1, -2, -1], [0, 0, 0], [1, 2, 1]]

    for (let y = 1; y < h - 1; y++) {
        for (let x = 1; x < w - 1; x++) {
            // Convolve
            const gX = 
                -1 * gray[(y - 1) * w + (x - 1)] + 1 * gray[(y - 1) * w + (x + 1)] +
                -2 * gray[y * w + (x - 1)]       + 2 * gray[y * w + (x + 1)] +
                -1 * gray[(y + 1) * w + (x - 1)] + 1 * gray[(y + 1) * w + (x + 1)];

            const gY = 
                -1 * gray[(y - 1) * w + (x - 1)] - 2 * gray[(y - 1) * w + x] - 1 * gray[(y - 1) * w + (x + 1)] +
                1 * gray[(y + 1) * w + (x - 1)] + 2 * gray[(y + 1) * w + x] + 1 * gray[(y + 1) * w + (x + 1)];

            const magnitude = Math.min(255, Math.sqrt(gX * gX + gY * gY));
            const idx = (y * w + x) * 4;

            outData[idx] = magnitude;
            outData[idx + 1] = magnitude;
            outData[idx + 2] = magnitude;
            outData[idx + 3] = 255;
        }
    }

    // Fill borders with 0 (since convolution skips edges)
    for (let x = 0; x < w; x++) {
        const topIdx = x * 4;
        const bottomIdx = ((h - 1) * w + x) * 4;
        outData[topIdx + 3] = 255;
        outData[bottomIdx + 3] = 255;
    }
    for (let y = 0; y < h; y++) {
        const leftIdx = (y * w) * 4;
        const rightIdx = (y * w + w - 1) * 4;
        outData[leftIdx + 3] = 255;
        outData[rightIdx + 3] = 255;
    }

    return output;
}

/**
 * Suggests 4 corners of a document in an image.
 * Uses a simple bounding box heuristic or edge scan.
 * @param {ImageData} imageData - Source image data
 * @returns {Array<{x: number, y: number}>} - 4 points (TL, TR, BR, BL)
 */
export function autoDetectCorners(imageData) {
    const w = imageData.width;
    const h = imageData.height;

    // Fallback/Default: 10% margins around the borders
    const defaultCorners = [
        { x: Math.round(w * 0.15), y: Math.round(h * 0.15) }, // TL
        { x: Math.round(w * 0.85), y: Math.round(h * 0.15) }, // TR
        { x: Math.round(w * 0.85), y: Math.round(h * 0.85) }, // BR
        { x: Math.round(w * 0.15), y: Math.round(h * 0.85) }  // BL
    ];

    try {
        // Run Sobel edge detection to find document boundaries
        const edgeImage = sobelEdgeDetection(imageData);
        const edgeData = edgeImage.data;
        
        // Find high intensity gradient pixels
        // Let's divide the image into 4 quadrants and find the extreme points with high gradients.
        // We look for:
        // TL: Minimizes x + y
        // TR: Maximizes x - y
        // BR: Maximizes x + y
        // BL: Minimizes x - y
        // We only consider pixels that are active edges (magnitude > 40) to filter noise.

        let bestTL = { x: 0, y: 0, score: Infinity };
        let bestTR = { x: 0, y: 0, score: -Infinity };
        let bestBR = { x: 0, y: 0, score: -Infinity };
        let bestBL = { x: 0, y: 0, score: Infinity };

        const threshold = 40;
        const margin = Math.round(Math.min(w, h) * 0.05); // Ignore exact frame borders

        for (let y = margin; y < h - margin; y += 2) { // Step by 2 to speed up scan
            for (let x = margin; x < w - margin; x += 2) {
                const idx = (y * w + x) * 4;
                const edgeVal = edgeData[idx]; // Sobel output in grayscale
                
                if (edgeVal > threshold) {
                    const sum = x + y;
                    const diff = x - y;

                    // TL: Minimize sum (top-leftmost)
                    if (sum < bestTL.score) {
                        bestTL.x = x;
                        bestTL.y = y;
                        bestTL.score = sum;
                    }
                    // BR: Maximize sum (bottom-rightmost)
                    if (sum > bestBR.score) {
                        bestBR.x = x;
                        bestBR.y = y;
                        bestBR.score = sum;
                    }
                    // TR: Maximize diff (top-rightmost)
                    if (diff > bestTR.score) {
                        bestTR.x = x;
                        bestTR.y = y;
                        bestTR.score = diff;
                    }
                    // BL: Minimize diff (bottom-leftmost)
                    if (diff < bestBL.score) {
                        bestBL.x = x;
                        bestBL.y = y;
                        bestBL.score = diff;
                    }
                }
            }
        }

        // Validate that we found suitable corners that aren't too close together
        const minDistance = Math.min(w, h) * 0.2;
        
        const dist = (p1, p2) => Math.sqrt((p1.x - p2.x)**2 + (p1.y - p2.y)**2);

        if (
            bestTL.score === Infinity ||
            dist(bestTL, bestTR) < minDistance ||
            dist(bestTR, bestBR) < minDistance ||
            dist(bestBR, bestBL) < minDistance ||
            dist(bestBL, bestTL) < minDistance
        ) {
            return defaultCorners;
        }

        return [
            { x: bestTL.x, y: bestTL.y },
            { x: bestTR.x, y: bestTR.y },
            { x: bestBR.x, y: bestBR.y },
            { x: bestBL.x, y: bestBL.y }
        ];

    } catch (e) {
        console.error("Corner detection failed, using defaults", e);
        return defaultCorners;
    }
}
