# Native PowerShell HTTP Server for AuraScan OCR
$port = 8080
$localPath = "C:\Users\dell\.gemini\antigravity\scratch\ocr-scanner"
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")

try {
    $listener.Start()
    Write-Host "HTTP Server started successfully!"
    Write-Host "Serving files from: $localPath"
    Write-Host "URL: http://localhost:$port/"
} catch {
    Write-Error "Failed to start listener on port $port. Is another server running on this port? Details: $_"
    exit 1
}

try {
    while ($listener.IsListening) {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response
        
        $urlPath = $request.Url.LocalPath
        if ($urlPath -eq "/") {
            $urlPath = "/index.html"
        }
        
        # Prevent directory traversal attacks by normalizing and verifying path
        $normalizedPath = [System.IO.Path]::GetFullPath((Join-Path $localPath $urlPath))
        if (-not $normalizedPath.StartsWith($localPath, [System.StringComparison]::OrdinalIgnoreCase)) {
            $response.StatusCode = 403
            $errBytes = [System.Text.Encoding]::UTF8.GetBytes("403 Forbidden")
            $response.ContentLength64 = $errBytes.Length
            $response.OutputStream.Write($errBytes, 0, $errBytes.Length)
            $response.OutputStream.Close()
            continue
        }

        if (Test-Path $normalizedPath -PathType Leaf) {
            $bytes = [System.IO.File]::ReadAllBytes($normalizedPath)
            
            # Detect MIME types
            $ext = [System.IO.Path]::GetExtension($normalizedPath).ToLower()
            switch ($ext) {
                ".html" { $contentType = "text/html; charset=utf-8" }
                ".css"  { $contentType = "text/css; charset=utf-8" }
                ".js"   { $contentType = "application/javascript; charset=utf-8" }
                ".json" { $contentType = "application/json; charset=utf-8" }
                ".png"  { $contentType = "image/png" }
                ".jpg"  { $contentType = "image/jpeg" }
                ".jpeg" { $contentType = "image/jpeg" }
                ".webp" { $contentType = "image/webp" }
                ".svg"  { $contentType = "image/svg+xml" }
                default { $contentType = "application/octet-stream" }
            }
            $response.ContentType = $contentType
            $response.ContentLength64 = $bytes.Length
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
        } else {
            $response.StatusCode = 404
            $errBytes = [System.Text.Encoding]::UTF8.GetBytes("404 Not Found")
            $response.ContentLength64 = $errBytes.Length
            $response.OutputStream.Write($errBytes, 0, $errBytes.Length)
        }
        $response.OutputStream.Close()
    }
} catch {
    Write-Host "Server stopped or encountered an error: $_"
} finally {
    if ($listener.IsListening) {
        $listener.Stop()
    }
}
