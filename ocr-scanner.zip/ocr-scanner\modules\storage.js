/**
 * Storage Manager Module
 * Manages saving, loading, deleting, and updating scanned documents.
 * Employs canvas compression to store small thumbnails alongside document text.
 */

const STORAGE_KEY = 'ocr_scanner_documents';

/**
 * Generate a unique ID.
 * @returns {string}
 */
export function generateId() {
    return 'doc_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

/**
 * Creates a highly compressed thumbnail of a canvas.
 * @param {HTMLCanvasElement} canvas - The source canvas containing the document image.
 * @param {number} maxWidth - Maximum width of the thumbnail.
 * @param {number} quality - JPEG quality from 0.0 to 1.0.
 * @returns {Promise<string>} - Resolve to base64 JPEG data URL.
 */
export function createThumbnail(canvas, maxWidth = 150, quality = 0.5) {
    return new Promise((resolve) => {
        try {
            const tempCanvas = document.createElement('canvas');
            const ratio = canvas.height / canvas.width;
            tempCanvas.width = maxWidth;
            tempCanvas.height = Math.round(maxWidth * ratio);

            const ctx = tempCanvas.getContext('2d');
            ctx.drawImage(canvas, 0, 0, tempCanvas.width, tempCanvas.height);
            
            // Export as JPEG with lower quality for maximum compression
            const dataUrl = tempCanvas.toDataURL('image/jpeg', quality);
            resolve(dataUrl);
        } catch (e) {
            console.error("Failed to create thumbnail", e);
            resolve(""); // Fallback to empty string
        }
    });
}

/**
 * Retrieve all documents from storage, sorted by date descending.
 * @returns {Array<Object>}
 */
export function getDocuments() {
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (!raw) return [];
        const docs = JSON.parse(raw);
        // Sort: newest first
        return docs.sort((a, b) => new Date(b.date) - new Date(a.date));
    } catch (e) {
        console.error("Failed to parse storage", e);
        return [];
    }
}

/**
 * Save a document.
 * @param {Object} doc - Document to save.
 * @param {string} doc.id - Document ID (will generate if empty).
 * @param {string} doc.title - Document Title.
 * @param {string} doc.text - Document raw OCR text.
 * @param {string[]} doc.tags - Array of tags.
 * @param {string} doc.thumbnail - Data URL thumbnail.
 * @returns {Object} - The saved document.
 */
export function saveDocument(doc) {
    const docs = getDocuments();
    
    const newDoc = {
        id: doc.id || generateId(),
        title: doc.title || 'Untitled Document',
        text: doc.text || '',
        tags: doc.tags || [],
        date: doc.date || new Date().toISOString(),
        thumbnail: doc.thumbnail || ''
    };

    const index = docs.findIndex(d => d.id === newDoc.id);
    if (index !== -1) {
        // Update existing document
        docs[index] = newDoc;
    } else {
        // Insert new document
        docs.push(newDoc);
    }

    localStorage.setItem(STORAGE_KEY, JSON.stringify(docs));
    return newDoc;
}

/**
 * Delete a document by ID.
 * @param {string} id - ID of the document to delete.
 * @returns {boolean} - Success status.
 */
export function deleteDocument(id) {
    const docs = getDocuments();
    const filtered = docs.filter(d => d.id !== id);
    if (docs.length === filtered.length) return false;
    
    localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
    return true;
}

/**
 * Update specific fields on an existing document.
 * @param {string} id - Document ID.
 * @param {Object} fields - Fields to update.
 * @returns {Object|null} - Updated document, or null.
 */
export function updateDocument(id, fields) {
    const docs = getDocuments();
    const index = docs.findIndex(d => d.id === id);
    if (index === -1) return null;

    docs[index] = {
        ...docs[index],
        ...fields
    };

    localStorage.setItem(STORAGE_KEY, JSON.stringify(docs));
    return docs[index];
}

/**
 * Calculate storage metrics.
 * @returns {{usedBytes: number, totalLimitBytes: number, percentUsed: number}}
 */
export function getStorageStats() {
    let total = 0;
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw) {
            total = raw.length * 2; // UTF-16 character is 2 bytes
        }
    } catch (e) {
        console.error(e);
    }
    
    // LocalStorage typical capacity is 5MB (5,242,880 bytes)
    const limit = 5 * 1024 * 1024;
    return {
        usedBytes: total,
        totalLimitBytes: limit,
        percentUsed: Math.min(100, (total / limit) * 100)
    };
}
