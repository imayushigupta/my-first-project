/**
 * Text-to-Speech (TTS) Engine Module
 * Interfaces with the Web Speech API to read scanned documents aloud.
 */

// Mapping of Tesseract OCR languages to Speech Synthesis locales
const LANG_MAP = {
    'eng': 'en-US',
    'spa': 'es-ES',
    'fra': 'fr-FR',
    'deu': 'de-DE',
    'chi_sim': 'zh-CN',
    'jpn': 'ja-JP'
};

export class TTSEngine {
    constructor() {
        this.synth = window.speechSynthesis;
        /** @type {SpeechSynthesisUtterance|null} */
        this.utterance = null;
        this.currentText = "";
    }

    /**
     * Map OCR language key to Speech Synthesis language code.
     * @param {string} ocrLang
     * @returns {string}
     */
    _getSpeechLanguage(ocrLang) {
        return LANG_MAP[ocrLang] || 'en-US';
    }

    /**
     * Speak text aloud.
     * @param {string} text - Text to speak.
     * @param {string} ocrLang - OCR language code.
     * @param {number} rate - Speech speed rate (0.5 to 2.0).
     * @param {Function} onStart - Callback when speech starts.
     * @param {Function} onEnd - Callback when speech ends or stops.
     */
    speak(text, ocrLang = 'eng', rate = 1.0, onStart = null, onEnd = null) {
        this.stop(); // Stop any current speech

        if (!text || text.trim().length === 0) return;

        this.currentText = text;
        this.utterance = new SpeechSynthesisUtterance(text);
        
        // Find best matching voice for this language
        const speechLang = this._getSpeechLanguage(ocrLang);
        this.utterance.lang = speechLang;

        // Set speed rate
        this.utterance.rate = Math.max(0.5, Math.min(2.0, rate));

        // Attempt to find a native voice speaking this locale
        if (this.synth.getVoices) {
            const voices = this.synth.getVoices();
            const voice = voices.find(v => v.lang.startsWith(speechLang) || v.lang.includes(speechLang.replace('-', '_')));
            if (voice) {
                this.utterance.voice = voice;
            }
        }

        // Setup callbacks
        this.utterance.onstart = () => {
            if (onStart) onStart();
        };

        this.utterance.onend = () => {
            this.utterance = null;
            if (onEnd) onEnd();
        };

        this.utterance.onerror = (event) => {
            console.error("Speech Synthesis error:", event);
            this.utterance = null;
            if (onEnd) onEnd();
        };

        this.synth.speak(this.utterance);
    }

    /**
     * Pause speaking.
     */
    pause() {
        if (this.synth.speaking && !this.synth.paused) {
            this.synth.pause();
        }
    }

    /**
     * Resume speaking.
     */
    resume() {
        if (this.synth.paused) {
            this.synth.resume();
        }
    }

    /**
     * Stop speaking and clear speak queue.
     */
    stop() {
        this.synth.cancel();
        this.utterance = null;
    }

    /**
     * Check if currently active or paused.
     * @returns {boolean}
     */
    isActive() {
        return this.synth.speaking;
    }

    /**
     * Check if currently paused.
     * @returns {boolean}
     */
    isPaused() {
        return this.synth.paused;
    }
}
